import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:group_project/about_us.dart';
import 'package:group_project/joke_page.dart';

import 'data_page.dart';
import 'login_page.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Center(
          child: Text(
            'Home Page',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
        ),
      ),
      body: Stack(
        children: [
          Container(
            alignment: Alignment.center,
            child: logoWidget("asset/logo1.png"),
          ),
          const Positioned.fill(
            top: 280,
            left: 60,
            child: Text(
              'Welcome to Our App!',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          Positioned(
            top: 120,
            right: 20,
            child: ElevatedButton(
              child: const Text("Log Out"),
              onPressed: () {

                FirebaseAuth.instance.signOut().then((value) {
                  print("Log Out");
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LogInScreen()),
                  );
                });
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.deepPurple,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(
              icon: Icon(Icons.home_outlined),
              color: _selectedIndex == 0 ? Colors.white : Colors.black,
              onPressed: () {
                setState(() {
                  _selectedIndex = 0;
                });
                // Navigate to the HomeScreen
                // You can replace HomeScreen with your desired screen
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomeScreen()),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.person_pin_outlined),
              color: _selectedIndex == 1 ? Colors.white : Colors.black,
              onPressed: () {
                setState(() {
                  _selectedIndex = 1;
                });
                // Navigate to the AboutUsWidget
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AboutUs()),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.local_bar_outlined),
              color: _selectedIndex == 2 ? Colors.white : Colors.black,
              onPressed: () {
                setState(() {
                  _selectedIndex = 2;
                });
                // Navigate to the JokesWidget
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => JokePage()),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.developer_mode),
              color: _selectedIndex == 3 ? Colors.white : Colors.black,
              onPressed: () {
                setState(() {
                  _selectedIndex = 3;
                });
                // Navigate to the DataWidget
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DataPage()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

Image logoWidget(String imageName) {
  return Image.asset(
    imageName,
    fit: BoxFit.fitWidth,
    width: 200,
    height: 200,
    color: Colors.white,
  );
}
