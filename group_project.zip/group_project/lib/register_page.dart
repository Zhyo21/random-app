import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:group_project/home_Page.dart';
import 'background_color.dart';
import 'login_page.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final TextEditingController _passwordController= TextEditingController();
  final TextEditingController _emailController= TextEditingController();
  final TextEditingController _userController= TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Center(
          child: Text('Registration Page',style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),
          ),
        ),
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.width,

    decoration: BoxDecoration
    (gradient: LinearGradient(colors:
    [hexStringToColor("CB2B93"),
    hexStringToColor("9546C4"),
    hexStringToColor("5E61F4"),
    ],
        begin: Alignment.topCenter, end: Alignment.bottomCenter
    )),
    child:SingleChildScrollView(
    child: Padding(padding: const EdgeInsets.fromLTRB(20, 120, 20, 0),
    child: Column(
    children: <Widget>[
    const SizedBox(
    height: 20,
    ),
      textt("Enter Email Id", Icons.email_outlined,false,_emailController),
      const SizedBox(
        height: 20,
      ),
      textt("Enter Username", Icons.person_outline,false,_userController),
      const SizedBox(
        height: 20,
      ),
      textt("Enter Password", Icons.lock_outline,false,_passwordController),
      const SizedBox(
        height: 20,
      ),
      button(context, false,() {
        FirebaseAuth.instance
            .createUserWithEmailAndPassword(
            email: _emailController.text,
            password: _passwordController.text).
        then((value) {
          print("Created New Account");
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => HomeScreen()));
        }).onError((error, stackTrace) {
          print("Error ${error.toString()}");
        });
      }),
      ],
    ),
    )
    )
      )
    );
  }
}
