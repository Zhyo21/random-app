import 'package:flutter/material.dart';

import 'home_Page.dart';

class AboutUs extends StatefulWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  State<AboutUs> createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.purple,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Center(

          child: Text('About Us Page',style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(),

    );
  }
}
